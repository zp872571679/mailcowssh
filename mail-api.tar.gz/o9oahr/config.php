<?php

ini_set('display_errors', 0);
error_reporting(0);

$config = [
    'key' => 'FzFA1DAh3k0tI6Q4',
    'api_key' => '142209-A06EFE-8FAF28-4C2E24-CFBB02',
    'server' => 'mail.lka45ks.top'
];
