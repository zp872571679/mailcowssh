<?php
// 引入必要的依赖文件
require_once 'config.php';
require_once 'vendor/autoload.php';

// 使用 Symfony HttpFoundation 组件和 PhpImap 的类
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use PhpImap\Mailbox;

/**
 * 用于美化视觉呈现的CSS样式。
 * 采用最简单的静态布局，彻底解决遮挡问题。
 */
$styles = "
<style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol';
        line-height: 1.6;
        color: #333;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0; /* 移除所有内边距 */
    }

    /*
     * ↓↓↓ 关键修改在这里 ↓↓↓
     * 不再使用 position: fixed，标题栏将作为普通块级元素存在。
     * 它会占据正常的空间，并随页面滚动。
    */
    .page-header {
        /* position: fixed; 已被移除 */
        height: 60px;
        width: 100%; /* 宽度占满 */
        background-color: #343a40;
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .page-header h1 {
        margin: 0;
        font-size: 22px;
        font-weight: 500;
    }

    /*
     * 为内容容器增加上外边距，
     * 以便在它和上方的标题栏之间创建一些视觉间距。
    */
    .container {
        max-width: 850px;
        margin: 30px auto 40px auto; /* 顶部30px, 左右自动, 底部40px */
        background-color: #ffffff;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 40px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    
    /* 以下样式保持不变 */
    .email-header {
        border-bottom: 1px solid #eee;
        padding-bottom: 20px;
        margin-bottom: 20px;
    }
    .email-header div { margin-bottom: 8px; font-size: 16px; }
    .email-header strong { display: inline-block; width: 80px; color: #555; }
    .email-subject { font-size: 24px; font-weight: bold; margin-bottom: 15px; color: #222; }
    .attachments span { display: inline-block; background-color: #e9ecef; border-radius: 12px; padding: 4px 12px; font-size: 14px; margin-right: 8px; margin-top: 5px; }
    pre { white-space: pre-wrap; word-wrap: break-word; background-color: #f1f1f1; padding: 15px; border-radius: 5px; border: 1px solid #ccc; font-family: monospace; font-size: 14px; }
    .message-box { text-align: center; padding: 15px; border-radius: 5px; font-size: 16px; margin-bottom: 20px; }
    .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .info { background-color: #e2e3e5; color: #383d41; border: 1px solid #d6d8db; }
    .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
</style>
";

/**
 * 辅助函数，用于将内容封装到完整的HTML结构中。
 * 新增了固定的 <header> 元素。
 */
function createHtmlPage($title, $content, $styles) {
    return <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    $styles
</head>
<body>
    <header class="page-header">
        <h1>邮件内容查看器</h1>
    </header>

    <div class="container">
        $content
    </div>
</body>
</html>
HTML;
}

// === 程序开始 ===
$request = Request::createFromGlobals();
$response = new Response();
$response->headers->set('Content-Type', 'text/html; charset=utf-8');

$email = $request->get('email');
$password = $request->get('password');
// 将 delete 参数转换为布尔值或字符串 '1'，方便后续判断
$delete_request = $request->get('delete');

if (empty($email) || empty($password)) {
    $content = "<div class='message-box error'>错误：电子邮件和密码是必填项。</div>";
    $response->setContent(createHtmlPage('输入错误', $content, $styles));
    $response->setStatusCode(Response::HTTP_BAD_REQUEST);
    $response->send();
    exit;
}

try {
    $mailbox = new Mailbox(
        '{' . $config['server'] . ':993/imap/ssl}INBOX',
        $email,
        $password,
        __DIR__,
        'UTF-8'
    );

    $mailsIds = $mailbox->searchMailbox('ALL');

    if (!$mailsIds) {
        $content = "<div class='message-box info'>收件箱中未找到任何邮件。</div>";
        $response->setContent(createHtmlPage('收件箱为空', $content, $styles));
    } else {
        $latestMailId = array_pop($mailsIds);

        // --- 修复点 1: 检查 $latestMailId 是否为空 ---
        if ($latestMailId === null) {
            // 这种情况理论上在 ! $mailsIds 已经覆盖了，但以防万一
            $content = "<div class='message-box info'>无法获取最新的邮件ID。</div>";
            $response->setContent(createHtmlPage('操作失败', $content, $styles));
        } else {
            $mail = $mailbox->getMail($latestMailId);

            // 1. 先将所有需要展示的内容保存到变量中
            $emailBody = $mail->textHtml ? $mail->textHtml : '<pre>' . htmlspecialchars($mail->textPlain, ENT_QUOTES, 'UTF-8') . '</pre>';
            
            $fromName = $mail->fromName ? htmlspecialchars($mail->fromName) : '';
            $fromEmail = htmlspecialchars($mail->fromAddress);
            $toList = htmlspecialchars(implode(', ', array_keys($mail->to)));

            $emailHeader = '
                <div class="email-header">
                    <div class="email-subject">' . htmlspecialchars($mail->subject) . '</div>
                    <div><strong>发件人:</strong> ' . $fromName . ' <' . $fromEmail . '></div>
                    <div><strong>收件人:</strong> ' . $toList . '</div>
                    <div><strong>日　期:</strong> ' . htmlspecialchars($mail->date) . '</div>
            ';
            
            $attachments = $mail->getAttachments();
            if (!empty($attachments)) {
                $emailHeader .= '<div class="attachments"><strong>附件:</strong> ';
                foreach ($attachments as $attachment) {
                    $emailHeader .= '<span>' . htmlspecialchars($attachment->name) . '</span>';
                }
                $emailHeader .= '</div>';
            }
            $emailHeader .= '</div>';

            // 2. 检查是否需要删除，并准备删除状态信息
            $deletionStatus = '';
            // --- 修复点 2: 确保 $latestMailId 有效且 delete 参数为 '1' ---
            if ($delete_request === '1') {
                try {
                    $mailbox->deleteMail($latestMailId); // 尝试删除邮件
                    $deletionStatus = '<div class="message-box success">此邮件已在服务器上成功删除。</div>';
                } catch (Exception $deleteEx) {
                    // --- 修复点 3: 捕获删除邮件时可能发生的异常 ---
                    $errorMessage = "<strong>删除邮件失败：</strong><br><pre>" . htmlspecialchars($deleteEx->getMessage(), ENT_QUOTES, 'UTF-8') . "</pre>";
                    $deletionStatus = "<div class='message-box error'>$errorMessage</div>";
                    // 如果删除失败，我们仍然显示邮件内容，但会告知用户失败信息
                    // 此时我们不改变响应的状态码，而是将错误信息显示在页面上
                }
            }
            
            // 3. 组合所有内容，准备发送给网页
            $finalContent = $deletionStatus . $emailHeader . $emailBody;
            $response->setContent(createHtmlPage('邮件查看器: ' . htmlspecialchars($mail->subject), $finalContent, $styles));
        }
    }
} catch (Exception $ex) {
    // 捕获连接、获取邮件等过程中的异常
    $errorMessage = "<strong>获取邮件失败：</strong><br><pre>" . htmlspecialchars($ex->getMessage(), ENT_QUOTES, 'UTF-8') . "</pre>";
    $content = "<div class='message-box error'>$errorMessage</div>";
    $response->setContent(createHtmlPage('连接错误', $content, $styles));
    $response->setStatusCode(Response::HTTP_INTERNAL_SERVER_ERROR); // 保持500状态码表示服务器内部错误
}

// 4. 发送最终构建好的网页内容
$response->send();