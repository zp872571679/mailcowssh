<?php
require_once 'config.php';
require_once 'vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use GuzzleHttp\Client;

$request = Request::createFromGlobals();

$key = $request->get('key');

// Default result is an empty array
$result = ['data' => []];
$domain = urldecode($request->get('domain'));
$num = urldecode($request->get('num'));

if ($key === $config['key'] ) {
    try {
        if (empty($domain)) {
            $domain = '';
        }

        if (!empty($num) && !is_numeric($num)) {
            $result['code'] = -1;
        }else{
            $client = new Client([
            'base_uri' => 'https://' . $config['server'],
        ]);
        $apiResponse = $client->get("/api/v1/get/mailbox/all/$domain", [
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-Key' => $config['api_key'],
            ],
        ]);

        if ($apiResponse->getStatusCode() === 200) {
            $contents = json_decode($apiResponse->getBody()->getContents(), true);
            
            // Check if the decoded content is an array
            if (is_array($contents)) {
                // Use array_column to efficiently extract all 'domain_name' values
                $result['data']= array_column($contents, 'username');
                $length = count($result['data']);
                if(!empty($num)){
                    $num = intval($num);
                    if ($num > 0 && $num < $length) {
                        $result['data'] = array_slice($result['data'], 0, $num);
                    }
                }

                $apiResponse = $client->post("/api/v1/delete/mailbox", [
                    'json' => $result['data'],
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'X-API-Key' => $config['api_key'],
                    ],
                ]);

                if ($apiResponse->getStatusCode() === 200) {
                    $contents = json_decode($apiResponse->getBody()->getContents(), true);
                    $result['code'] = $contents[0]['type'] === 'success' ? 0 : -1;
                } else {
                    $result['code'] = -1; // Indicate failure
                }

            }
        }
        }
    }catch (\Exception $e) {
        // Handle potential exceptions from the API call (e.g., timeout, connection error)
        $result['code'] = -1;
    }
} else {
    $result['code'] = -1;
}

$response = new Response();
$response->setContent(json_encode($result));
$response->headers->set('Content-Type', 'application/json');
$response->send();