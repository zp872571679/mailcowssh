<?php
require_once 'config.php';
require_once 'vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use GuzzleHttp\Client;

$request = Request::createFromGlobals();

$key = $request->get('key');

// Default result is an empty array
$result = ['data' => []];

if ($key === $config['key']) {
    try {
        $client = new Client([
            'base_uri' => 'https://' . $config['server'],
        ]);

        $apiResponse = $client->get('/api/v1/get/domain/all', [
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-Key' => $config['api_key'],
            ],
        ]);

       if ($apiResponse->getStatusCode() === 200) {
            $contents = json_decode($apiResponse->getBody()->getContents(), true);
            
            // Check if the decoded content is an array
            if (is_array($contents)) {
                // Use array_column to efficiently extract all 'domain_name' values
                $result['data'] = array_column($contents, 'domain_name');
                $result['code'] = 0; // Indicate success
            }
        }
    } catch (\Exception $e) {
        // Handle potential exceptions from the API call (e.g., timeout, connection error)
         $result['code'] = -1;
    }
} else {
    $result['code'] = -1;
}

$response = new Response();
$response->setContent(json_encode($result));
$response->headers->set('Content-Type', 'application/json');
$response->send();