<?php
require_once 'config.php';
require_once 'vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use PhpImap\Mailbox;

$request = Request::createFromGlobals();

$email = $request->get('email');
$password = $request->get('password');
$delete = $request->get('delete', false);

$result = ['code' => -1];

if (!empty($email) && !empty($password)) {
    $mailbox = new Mailbox(
        '{' . $config['server'] . ':993/imap/ssl}INBOX',
        $email,
        $password,
    );

    try {
        $mailsIds = $mailbox->searchMailbox('ALL');

        if ($mailsIds) {
            $latestMailId = array_pop($mailsIds);
            $mail = $mailbox->getMail($latestMailId);

            if ($mail->textHtml) {
                $result['content'] = $mail->textHtml;
            } else {
                $result['content'] = $mail->textPlain;
            }

            if ($delete == '1') {
                $mailbox->deleteMail($latestMailId);
            }

            $result['code'] = 0;
        } else {
            
        }
    } catch(Exception $ex) {
        $result['error'] = "获取邮件失败";
    }
}

$response = new Response();
$response->setContent(json_encode($result));
$response->headers->set('Content-Type', 'application/json');
$response->send();