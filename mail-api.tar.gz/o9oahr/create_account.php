<?php
require_once 'config.php';
require_once 'vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use GuzzleHttp\Client;

$request = Request::createFromGlobals();

$key = $request->get('key');

$result = ['code' => -1];

if ($key === $config['key']) {
    $data['local_part'] = urldecode($request->get('local_part'));
    $data['domain'] = urldecode($request->get('domain'));
    $data['password'] = urldecode($request->get('password'));
    $data['password2'] = $data['password'];
    $data['active'] = 1;

    if (!empty($data['local_part']) && !empty($data['domain']) && !empty($data['password'])) {
        $client = new Client([
            'base_uri' => 'https://' . $config['server'],
        ]);

        $response = $client->post('/api/v1/add/mailbox', [
            'json' => $data,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-Key' => $config['api_key'],
            ],
        ]);

        if ($response->getStatusCode() === 200) {
            $contents = json_decode($response->getBody()->getContents(), true);
            $result['code'] = $contents[0]['type'] === 'success' ? 0 : -1;
        }
    }
}

$response = new Response();
$response->setContent(json_encode($result));
$response->headers->set('Content-Type', 'application/json');
$response->send();