<?php

ini_set('display_errors', 0);
error_reporting(0);

$config = [
    'key' => 'FzFA1DAh3k0tI6Q4',
    'api_key' => '331359-6AD774-A5E845-698E06-F1BD8C',
    'server' => 'mail.pg999.icu'
];